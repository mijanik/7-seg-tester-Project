#ifndef LED_H
#define LED_H

#include "frdm_bsp.h"

/**
 * @brief Led State Types.
 */
typedef enum {
	LED_OFF 			= (uint8_t)0,
	LED_ON 				= (uint8_t)1,
	LED_TOGGLE 		= (uint8_t)2
} LedState_Type;
/**
 * @brief Led Segment Choice.
 */
typedef enum {
	LED_A 		= (uint8_t)0,
	LED_B 		= (uint8_t)1,
	LED_C 		= (uint8_t)2,
	LED_D 		= (uint8_t)3,
	LED_E 		= (uint8_t)4,
	LED_F 		= (uint8_t)5,
	LED_G 		= (uint8_t)6,
	LED_DP 		= (uint8_t)7
} Ledsegment_Type;
/**
 * @brief Structure containing info about pin.
 */
typedef struct {
	GPIO_Type 	*gpio;        /* GPIO base pointer */
	PORT_Type 	*port;        /* PORT base pointer */
	uint32_t		clk_mask;     /* Mask for SCGC5 register */
	uint8_t  		pin;          /* Number of PIN */
} PinStruct_Type;

/**
 * @brief LEDs initialization.
 */
void LED_Init (void);


/**
* @brief Select display
*
* @param Display number
*/
void DISP_Select(int disp_num);


/**
 * @brief Control choosen LED.
 *
 * @param segment of a LED.
 * @param State of a LED.
 */
void LED_Ctrl(Ledsegment_Type segment, LedState_Type led_state);


/**
 * @brief Blink choosen LED segment one time.
 *
 * @param segment of LED.
 */
void LED_Blink (Ledsegment_Type segment, uint32_t time);

#endif /* LED_H */
