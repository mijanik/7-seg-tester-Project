/**
* @file main.c
* @authors Milosz Janik & Antoni Kijania
* @date Nov 2021
* @brief File containing the main function.
* @ver 0.0.1
*/
#include "led.h"
#define time 50

int main (void) {
	LED_Init (); /* initialize all LEDs */
	while(1){
		
		for(int k=0; k<4; k++){
			DISP_Select(k);
			
			LED_Blink(LED_A, time);
			LED_Blink(LED_B, time);
			LED_Blink(LED_C, time);
			LED_Blink(LED_D, time);
			LED_Blink(LED_E, time);
			LED_Blink(LED_F, time);
			LED_Blink(LED_G, time);
			LED_Blink(LED_DP, time);
		}
	}
}
